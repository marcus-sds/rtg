#!/bin/bash

HOME_DIR="/usr/local/rtg/etc_err"
POLLER=`hostname`
MYSQLBIN="/usr/local/mysql/bin/mysql -u snmp -prtgdfault rtg"

TARGET=targets.cfg

intface_err() {

cat routers | while read LINE
do
HOST=`echo $LINE|awk -F: '{print $1}'`
COMMUNITY=`echo $LINE|awk -F: '{print $2}'`
IP=`grep " $HOST$" /etc/hosts|awk '{print $1}'`

$MYSQLBIN -e "select '${IP}',concat('$MIB',substring(a.name,instr(a.name,'-')+1,length(a.name))),32,'${COMMUNITY}','${TABLE}',a.id from interface a,router b where b.name='${HOST}' and a.rid = b.rid and b.moddate > (now() - INTERVAL 7 DAY) and a.moddate > (now() - INTERVAL 7 DAY) and a.name not like '%VLAN%' and a.name not like '%channel%' " |grep -v concat|grep -v "NET'" >> $HOME_DIR/$TARGET
done
}

rm $HOME_DIR/$TARGET

TABLE="intface_outerr"
MIB="1.3.6.1.2.1.2.2.1.20."
intface_err

TABLE="intface_outdisc"
MIB="1.3.6.1.2.1.2.2.1.19."
intface_err

TABLE="intface_indisc"
MIB="1.3.6.1.2.1.2.2.1.13."
intface_err

TABLE="intface_inerr"
MIB="1.3.6.1.2.1.2.2.1.14."
intface_err
