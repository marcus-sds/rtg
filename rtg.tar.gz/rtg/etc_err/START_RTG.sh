kill -9 `ps -ef|grep etc_err/targets|awk '{print $2}'`
dir=`pwd`
nohup /usr/local/rtg/bin/rtgpoll -v -m -t ${dir}/targets.cfg &
