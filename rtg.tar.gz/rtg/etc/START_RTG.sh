kill -9 `ps -ef|grep etc/targets|awk '{print $2}'`
dir=`pwd`
nohup /usr/local/rtg/bin/rtgpoll -v -m -t ./targets.cfg &
rm -f nohup.out
