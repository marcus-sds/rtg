/usr/bin/perl /usr/local/rtg/etc/rtgtargmkr.pl
